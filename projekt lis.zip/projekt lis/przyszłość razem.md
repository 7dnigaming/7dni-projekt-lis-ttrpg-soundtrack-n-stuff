gang bez przywódcy chcący przyjmować wszystkich kogo popadnie aby później dużą ludnością pokonać korporacje L.I.S.
przyjazny ale czasami agresywny 
często zabijają czerwonych ponieważ czerwoni są zbyt "agresywni"