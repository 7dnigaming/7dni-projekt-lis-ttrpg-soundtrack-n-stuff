postacie sterowane przez CEO L.I.S. Corporation może mieć ich 2 jednocześnie z cooldown odrodzenia 24h
mają uprawnienia większę niż [[administratorzy]]