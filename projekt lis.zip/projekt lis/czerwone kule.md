gang z jednym przywódcą głównym ich celem jest zabić całą symulację zostawiając ich samych
przywódca oszukuję samych członków ponieważ po likwidacji symulacji chce on zabić członków gangu aby zostać sam a osoby dowiadujące się o tym nie żyją zbyt długo gdyż przywódca wystawia nagrody za ich zabicie

lubią hazard

nie mają pojęcia o [[białe kule|białych kulach]]
