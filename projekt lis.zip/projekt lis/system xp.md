xp jest naliczane:
	co każdy kill gracz dostaje 5xp
	różne ważniejsze akcje jak:        daje 3xp		
		uniknięcie śmierci, wykonanie zadania danego przez npc, itp.
	trafienie w rzucie kością d20 liczby 20 1xp




co można za xp
dodać klasę ddodatkową lub wziąść podklasę dla klasy którą masz - 100xp
