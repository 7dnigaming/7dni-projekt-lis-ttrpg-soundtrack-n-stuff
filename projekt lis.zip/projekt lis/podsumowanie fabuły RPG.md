"TO KONIEC... Korporacja L.I.S. To ŚCIEMA!..."
"Obiecali nam życie, dali nam piekło"
**==to jest fabuła po głównej grze... kilka lub kilkanaście albo nawet kilkaset lat później nikt nie wie==**
bohater znany jako 7dni został usunięty i jego wspólnik z prawdziwego życia zabity przez CEO Korporacji L.I.S.'a i teraz wszyscy utykają w tym oszustwie "życie po śmierci lub życie w symulacji"
każdy kto jest desperowany aby mieć życie po śmierci "gwarantowane" jest oszukiwany przez tą pojebaną korporację

a życie w symulacji jest... złe
gangi, tech-narkotyki, przerobiona broń antywirusowa która pozwala na usunięcie każdego po kilku strzałach
teraz nie wiem co robić... trzeba znaleść jakąś grupę debili która była by tak głupia aby spróbowali wyjść z symulacji i zabić tego zjeba "CEO" niech oni skończą ten problem...


stan symulacji jest bardzo zły
CEO bierze kasę ale nie wydaje jej na ulepszenie naszego życia
pozwala im nas zabijać, okradać, torturować nas, i gnębić

jesteś w symulacji jak wszyscy inni ponieważ ludzie z prawdziwego życia nie wiedzą jak źle jest...
straciłeś prawie całą pamięć po wejściu do symulacji... możesz nawet pamiętać jak się nazywasz

czytaj dalej: [[podsumowanie świata]]

