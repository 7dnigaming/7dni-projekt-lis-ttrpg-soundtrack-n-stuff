postacie o czerwonej skórze lub czymś co przypomina skórę
mówią w nie znanym języku
są agresywi wobeć wszystkich oprócz członków [[czerwona przyszłość|czerwonej przyszłości]]
są łatwi 10hp do zabicia ale często chodzą dużymi grupami