rzuć kością d4

1-nic nie mówi
2-kłamie/mówi sarkastycznie
3-odpowiada normalnie
4-odpowiada z przydatną podpowiedzią