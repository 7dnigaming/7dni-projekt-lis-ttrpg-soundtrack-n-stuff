gang bez przywódcy nie zbyt przyjazny dla nowych członków
próbują i eksperymentują różne metody komunikacji z "czerwonymi ludźmi"
zaczeli się z nimi zaprzyjaźniać znaleźli na to sposób ale nie wiedzą co mówią
ten gang nie chętnie przyjmuje nowych członków z powodu strachu przed wystraszeniem "czerwonych"
