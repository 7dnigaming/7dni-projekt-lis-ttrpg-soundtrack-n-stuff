mniejszę grupy przestępcze. 
zabijają, tępią, okradają co popadnie
są w mniejszych grupach ale bardziej uzbrojeni 18hp niż [[czerwoni]]
mogą być przerobieni technologią i robotyką ale nie muszą
