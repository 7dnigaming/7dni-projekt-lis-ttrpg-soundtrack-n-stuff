każdy gracz zaczyna z 20 + 2 wytrzymałości ma 1+

dla wroga:
	słabe zranienie - 1hp
	dobre zranienie - 4hp
	mocne zranienie - 7hp
	krytyczne zranienie - zabija
dla gracza
	słabe zranienie - 1hp
	dobre zranienie - 3hp
	mocne zranienie - 5hp
	krytyczne zranienie - zostaje:
		gracz ma ponad 10hp - zostaje graczowi 3hp
		gracz ma mniej niż 10hp - umiera

