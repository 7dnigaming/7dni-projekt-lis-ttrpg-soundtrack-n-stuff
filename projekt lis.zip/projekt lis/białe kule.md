mniej gang bardziej drużyna bez przywódcy chcąca wytępić [[czerwone kule]]
przyjmują wszystkich kto przejdzie u nich testy osobowości, lojalności i sprawności