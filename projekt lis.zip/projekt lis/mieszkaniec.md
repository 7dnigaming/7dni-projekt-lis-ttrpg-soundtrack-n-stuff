zwykły mieszkaniec symulacji chce po prostu żyć, czy w chaosie czy w spokoju większości nie interesuje

mogą to być:
informatycy
inżynierzy
medycy
badawcy
itp.