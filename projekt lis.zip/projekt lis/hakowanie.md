rzuć d20
zależnie od umiejętności informatycznych postaci:
nie zna się:
	1-19 nie udaje się i alarmuje
	20 nie udaje się
zna się:
	1-15 nie udaje się i alarmuje
	16-20 nie udaje się
umie hakować: 
	1-10 nie udaje się i alarmuje
	1-13 nie udaje się
	14-19 udaje się z szansą na alarm 
	20 udaje się
jest hackerem:
	1-5 nie udaje się i alarmuje
	5-7 nie udaje się
	8-10 udaje się z szansa na alarm
	11-18 udaje się
	19-20 udaje się bez śladów