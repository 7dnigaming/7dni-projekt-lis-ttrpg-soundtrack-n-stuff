W projekt: L.I.S. historii napisanej przez 7dni_gamingu [YouTube](https://www.youtube.com/@7dni-gamingu)
ta historia została jeszcze nie dokończona
UWAGA: TA FABUŁA RPG JEST PO GŁÓWNEJ OPOWIEŚCI 7DNI: PROJEKT L.I.S.

czytaj następnie: \[\[małe podsumowanie głównej fabuły]]

