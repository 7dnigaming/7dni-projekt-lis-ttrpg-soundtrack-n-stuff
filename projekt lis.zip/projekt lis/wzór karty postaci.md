PODSTAWOWE

pseudonim:
imie i nazwisko (jak nie pamiętasz po wejściu do symulacji napisz "-"):
płeć:
pochodzenie gangowe (nie obowiązkowe): 
klasa:
czy zna się na komputerach:

--------------------------------------------
WYGLĄD

wzrost:
budowa ciała:
kolor włosów:
cechy charakteryczne:

-----------------------------------
OSOBOWOŚĆ

charakter:
mocne strony:
słabe strony:
lęki:
cele:
cytat (nieobowiązkowe):

------------------
UMIEJĘTNOŚCI || max 30 punktów | max 10 w jednej kategorii

siła:
zręczność:
wytrzymałość:
inteligencja:
percepcja:
inna (nie obowiązkowe):
inna (nie obowiązkowe):
inna (nie obowiązkowe):

umiejętność specjalna aktywowana raz na dzień (nie obowiązkowe):

--------
EKWIPUNEK max 1 dopuki nie ma dwóch takich samych pomunerowanych

broń główna:
pancerz lekki:
narzędzia 1:
narzędzia 2:
inne:

-------
DODATKOWE

sojusznicy:
nawyki:
ciekawostki:


