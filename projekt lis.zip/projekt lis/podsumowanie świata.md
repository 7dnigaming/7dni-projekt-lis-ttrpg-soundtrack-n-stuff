[[gangi]]
[[npc]]
[[klasy postaci]]
