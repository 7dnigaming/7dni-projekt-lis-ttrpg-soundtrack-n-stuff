jak widzisz wroga możesz wywołać walkę lub zrobić po cichu

sposób cichy: 
	rzuć kością d20 jak trafisz
		od 0 do 3 nie udaję ci się 
		od 4 do 8 możesz spowodować aby wróg się rozejrzał
		od 9 do 16 podchodzisz po cichu ale wróg może się losowo rozejrzeć
		od 17 do 20+ podchodzisz po cichu
	 rzuć kością d20 za atak jak trafisz:
		 od 0 do 3 nie trafiasz
		 od 4 do 6 zraniasz delikatnie
		 od 7 do 10 zraniasz go dobrze i nie może się obronić większości czasów
		 od 11 do 16 zraniasz go mocno i nie może się obronić ale nie umiera
		 od 17 do 20 wróg ginie

sposób głośny:
	rzuć za inicjatywę
		jeśli twój ruch możesz poruszyć się max 8m i atakować
			jak atakujesz bronią palną rzuć d20
				nie parzyste - nietrafiasz
				parzyste -trafiasz
				celowanie daję dodatkowy rzut na cel (d6):
				1-2 nie trafiasz
				3-4 nie trafiasz w główny cel ale trafiasz w wroga
				5 trafiasz w cel
				6 trafiasz w miejsce krytyczne +1 damage
			jak atakujesz ręcznie lub bronią białą rzuć d4
				1-nie trafiasz
				2-ranisz go dobrze
				3-ranisz go mocno
				4-ranisz go krytycznie prawie do śmierci
		 