na start wybieramy klasę z "-" na początku

później są podklasy (bez "-") zdobywane za xp



\---lista

\-wojownik
strzelec
bokser
nożownik



\-łowca
łowca nagród
zabójca
hitman za kasę



\-medyk
medyk profesjonalny
scaner wirusów
człowiek-antywirus



\-informatyk
programista
łamacz zabezpieczeń
deaktywator systemów



\-inżynier
producent zabezpieczeń
automatyczny strzelec
automatyczna osłona

