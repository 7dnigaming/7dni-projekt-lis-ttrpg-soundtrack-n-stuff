Świat przedstawiony i założenia fabularne: Narracja śledzi losy świadomości bohatera uwięzionego w opuszczonej przestrzeni cyfrowej. Skrót „L.I.S.” oznacza „Life In Simulation” (Życie w symulacji) i stanowi jednocześnie dwujęzyczne nawiązanie do polskiego słowa oznaczającego lisa.

**Książka na Wattpadzie (materiał stanowiący prequel do gry 7dni: projekt L.I.S.):**
Bohater zgłasza się do eksperymentu z przeniesieniem umysłu pod hasłem „Life After Death” („Życie po śmierci”), reklamowanego przez Lis Corporation (w wyniku błędu tłumaczeniowego nazwa ta została kiedyś przetłumaczona jako „Fox Corporation” — w całym tekście należy jednak stosować nazwę Lis Corporation).

W trakcie finalizowania projektu bohater ginie w wypadku samochodowym – hamulce zostały sabotowane przez nieznajomego, którego wcześniej widziano, jak majstrował przy samochodzie.

Bohater budzi się w pokoju pełnym zakłóceń, nie pamiętając ani swojej tożsamości, ani imienia, tuż przed tym, jak symulacja pogrąża się w ciemności.

Niedokończony szkic rozdziału 2: bohater budzi się w opuszczonym mieście zamieszkanym przez wrogie istoty o czerwonej skórze/zainfekowane („czerwoni”), zabija jedną z nich w obronie własnej i słyszy przewodni głos – komunikacja jest jednokierunkowa – ostrzegający go, by unikał czerwonych. Głos dostarcza mu „pistolet antywirusowy” z nieograniczoną amunicją o niskiej mocy, tuż przed pojawieniem się hordy.

Powodem, dla którego w książce komunikacja z głosem jest jednokierunkowa, jest słabe połączenie — bohater później otrzymuje zestaw słuchawkowy z mikrofonem

bohater następnie walczy o przetrwanie w symulacji 

dla podsumowania fabuły RPG: [[podsumowanie fabuły RPG]]