gangi chcące lepszej przyszłości


[[czerwona przyszłość]]

[[przyszłość razem]] 


gangi robiącę byle co

[[czerwone kule]]

[[białe kule]]
