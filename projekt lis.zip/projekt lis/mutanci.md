nie udane testy na [[czerwoni|czerwonych]] wykonanych przez [[genetycy|genetyków]]
są bardziej nie bezpieczni niż [[czerwoni]]
ale czesto umierają po krótkim czasie od testu ale jak nie, to mogą być mocniejsi w wytrzymałość i siłę
mają różne hp 