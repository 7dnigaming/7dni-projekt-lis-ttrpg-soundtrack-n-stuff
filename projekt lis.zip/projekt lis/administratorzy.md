mało ludzi wie czy naprawdę istnieją
przy ramieniu (lewym jak prawo ręczny lub na odwrót) ma panel administratorski bez możliwości usuwania plików z powodu nie którzy administratorzy popadli w gangi
są oni rzadcy do znalezienia 